import React, { Component, useState } from "react";
import { Text, View, Button, Alert } from 'react-native';

//  function myFunction() {
//   if(
//     document.getElementById('selectid').value == "simples") {
//        var x = JurosT;
//     }
//   }
// }
  //  constructor(props) {
  //     super(props);
  //     // this.setState({ clicked: true });
  //     this.state = { myState: 'composto' };
// //    changeState = () => this.setState({myState: 'Hello World'})
// //    render(props) {
// //       return (
// //          <View style={{flex :1, justifyContent: 'center', margin: 15 }}>
// //             <View>
// //                <Text onPress={this.changeState} style={{color:'red', fontSize:25}}>                         {this.state.myState} </Text>
// //             </View>
// //          </View>
// //       );
// //    }
// // }
// export default App;
// jsfunc1()
// function myFunction() {
//   var x = document.getElementById("mySelect").value;
//   document.getElementById("demo").innerHTML = "You selected: " + x;
// }