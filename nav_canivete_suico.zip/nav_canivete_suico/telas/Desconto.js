import { StatusBar } from 'expo-status-bar';
import React, { useState } from "react";
import {StyleSheet, Text, View, Button, TextInput } from 'react-native';
import Estilos from '../estilos/Estilos';

export default function App() {

const [preço, setPreço] = useState('');
const [desconto, setDesconto] = useState('');
const [Result, setResult] = useState('');
const [descont2, setDesconto2] = useState('');


const ResultT = () => {
if (preço > 0 && desconto > 0) {
let valorResult = setResult (((parseFloat(preço) * parseFloat(desconto)) / 100 - preço) * -1);

} else {
let valorResult = setResult('Informe valores diferentes de Zero');
}
}

// function calcularResult () {
// if (preço > 0 && desconto > 0) {
//   setResult((parseFloat(preço) * parseFloat(desconto)) /2);
//   } else {
//   setResult(' ' );
//   }
// }

  return (
    <View style={Estilos.container}>
<Text>Insira os dados abaixo para calcular o valor com desconto.</Text>

<TextInput
placeholder="Preço ($)"
style={{ height: 40, textAlign: 'center', borderWidth: 1,}}
keyboardType={'numeric'}
value={preço}
onChangeText={text=>setPreço (text)}
/>

<TextInput
placeholder="Desconto (%)"
style={{ height: 40, textAlign: 'center', borderWidth: 1, }}
keyboardType={'numeric'}
onChangeText={text=>setDesconto (text)}
/>

<Button title='Calculddar' onPress={ResultT} />
<Text>{Result? `Valor com desconto: ${(Result) .toLocaleString('pt-BR', {style: 'currency', currency: 'BRL', minimumFractionDigits: 2})} ` : ''}</Text>
<StatusBar style="auto" />
    </View>
  );
}