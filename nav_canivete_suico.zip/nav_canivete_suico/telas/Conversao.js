import { StatusBar } from 'expo-status-bar';
import React, { useState } from "react";
import {StyleSheet, Text, View, Button, TextInput } from 'react-native';
import Estilos from '../estilos/Estilos';

export default function App() {

const [preço, setPreço] = useState('');
const [desconto, setDesconto] = useState('');
const [Result, setResult] = useState('');
const [descont2, setDesconto2] = useState('');


const ResultT = () => {
if (preço > 0) {
let valorResult = setResult (((parseFloat(preço) /5)));

// let valordesconto2 = setDesconto2 (((parseFloat(preço) * 5)));

} else {
let valorResult = setResult('Informe valores diferentes de Zero');
}
}

// function calcularResult () {
// if (preço > 0 && desconto > 0) {
//   setResult((parseFloat(preço) * parseFloat(desconto)) /2);
//   } else {
//   setResult(' ' );
//   }
// }

  return (
    <View style={Estilos.container}>
<Text>Insira os dados abaixo para calcular o valor com desconto.</Text>

<TextInput
placeholder="Valor em (R$)"
style={{ height: 40, textAlign: 'center', borderWidth: 1,}}
keyboardType={'numeric'}
value={preço}
onChangeText={text=>setPreço (text)}
/>

<Button title='Calculddar' onPress={ResultT} />
<Text>{Result? `Valor em dolár (aproximado): ${(Result) .toLocaleString('pt-BR', {style: 'currency', currency: 'BRL', minimumFractionDigits: 2})} ` : ''}</Text>
<StatusBar style="auto" />
    </View>
  );
}
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
// });

