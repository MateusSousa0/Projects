// import { StatusBar } from 'expo-status-bar';
// import React, { useState } from 'react';
// import { StyleSheet, Text, View, Button, TextInput } from 'react-native';
// import Estilos from '../estilos/Estilos';

// const [base, setBase] = useState('');
// const [altura, setAltura] = useState('');
// const [area, setArea] = useState('');

// const areaT = () => {
//   if (base > 0 && altura > 0) {
// let valorArea = setArea((parseFloat(base) * parseFloat(altura)) / 2);
// }
//   else {
// let valorArea = setArea('Informe valores diferentes de Zero');
//   } 
// }

// export default function AreaTriangulo(){
// return(
  
//   <View style={Estilos.container}>

// <Text>Insira os dados abaixo para calcular a área do triângulo.</Text>

// <TextInput
// placeholder="Base"
// style={{ height: 40, textAlign: 'center', borderWidth: 1,}}
// keyboardType={'numeric'}
// value={base}
// onChangeText={text=>setBase (text)}
// />

// <TextInput
// placeholder="Altura"
// style={{ height: 40, textAlign: 'center', borderWidth: 1, }}
// keyboardType={'numeric'}
// onChangeText={text=>setAltura (text)}
// />

// <Button title='Calcular' onPress={areaT} />
// <Text>{area? `Resultado: ${area} ` : ''}</Text>
// <StatusBar style="auto" />
// </View>
// );
// }
import { StatusBar } from 'expo-status-bar';
import React, { useState } from "react";
import {StyleSheet, Text, View, Button, TextInput } from 'react-native';
import Estilos from '../estilos/Estilos';

export default function App() {

const [preço, setPreço] = useState('');
const [desconto, setDesconto] = useState('');
const [Result, setResult] = useState('');
const [Desconto2, setDesconto2] = useState('');


const ResultT = () => {
if (preço > 0 && desconto > 0 && Result < 0.7) {
let valorResult = setResult (((parseFloat(preço) / parseFloat(desconto))));
let Desconto2 = "Vale mais a pena isso";}

// if (){
//   const Desconto2 ="Vale mais a pena isso";
// }

// let valordesconto2 = setDesconto2 (parseFloat(desconto) /100 * parseFloat(preço));
  else {
let valorResult = setResult('Informe valores diferentes de Zero');
}
}

// function calcularResult () {
// if (preço > 0 && desconto > 0) {
//   setResult((parseFloat(preço) * parseFloat(desconto)) /2);
//   } else {
//   setResult(' ' );
//   }
// }

  return (
    <View style={Estilos.container}>
<Text>Insira os dados abaixo para calcular o valor com desconto.</Text>

<TextInput
placeholder="Preço do Etanol (por litro)"
style={{ height: 40, textAlign: 'center', borderWidth: 1,}}
keyboardType={'numeric'}
value={preço}
onChangeText={text=>setPreço (text)}
/>

<TextInput
placeholder="Preço da Gasolina (por litro)"
style={{ height: 40, textAlign: 'center', borderWidth: 1, }}
keyboardType={'numeric'}
onChangeText={text=>setDesconto (text)}
/>

<Button title='Calcular' onPress={ResultT} />
<Text> {Desconto2}
</Text>


<StatusBar style="auto" />
    </View>
  );}