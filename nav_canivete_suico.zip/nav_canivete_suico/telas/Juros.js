import { StatusBar } from 'expo-status-bar';
import React, { useState, Component } from "react";
import {StyleSheet, Text, View, Button, TextInput } from 'react-native';
import Estilos from '../estilos/Estilos';

function myFunction() {
  if(
    document.getElementById('selectid').value == "simples") {
       var x = JurosT;
    }
  }

export default function App() {

const [capital, setCapital] = useState('');
const [taxa, setTaxa] = useState('');
const [Juros, setJuros] = useState('');
const [periodo, setPeriodo] = useState('');

//  function App() {
//   if(
//     document.getElementById('selectid').value == "simples") {
//        const x = JurosT;
//     }

const JurosT = () => {
  
if(capital > 0 && document.getElementById('selectid').value == "simples") {
  let valorJuros = setJuros (((parseFloat(capital) * parseFloat(taxa)) / 100 * periodo));
}
  else if(periodo < 0 && taxa < 0 && capital>0){
   let valorJuros = setJuros('Informe valores diferentes de Zero');
  }

 else {
  let valorJuros = setJuros('Informe valores diferentes de Zero');
}
}

const JurosC = () => {
  
if(capital > 0 && document.getElementById('selectid').value == "composto") {
  let valorJuros = setJuros (((parseFloat(capital) * parseFloat(taxa)) / 100 * periodo));
}
  else if(periodo < 0 && taxa < 0 && capital>0){
   let valorJuros = setJuros('Informe valores diferentes de Zero');
  }

 else {
  let valorJuros = setJuros('Informe valores diferentes de Zero');
}
}

  return (
    <View style={Estilos.container}>
<Text>Insira os dados abaixo para calcular os Juros simples.</Text>

<TextInput class="input"
placeholder="Capital ($)"
style={{ height: 40, textAlign: 'center', borderWidth: 1,}}
keyboardType={'numeric'}
value={capital}
onChangeText={text=>setCapital (text)}
/>

<TextInput class="input"
placeholder="Taxa (em %)"
style={{ height: 40, textAlign: 'center', borderWidth: 1, }}
keyboardType={'numeric'}
onChangeText={text=>setTaxa (text)}
/>

<TextInput class="input"
placeholder="Tempo (em messes)"
style={{ height: 40, textAlign: 'center', borderWidth: 1, }}
keyboardType={'numeric'}
onChangeText={text=>setPeriodo (text)}
/>

<select name="selectname" onchange="myFunction()" id="selectid">
    <option value="simples" id="simples"> Simples </option>

    <option value="composto" id="composto" onClick={() => handleClick} > Composto </option>

   
</select>

 <Button title='Calcular'/>
    //if ()//
    {JurosC}; )


  <Text>{Juros? `Valor com taxa: ${(Juros) .toLocaleString('pt-BR', {style: 'currency', currency: 'BRL', minimumFractionDigits: 2})} ` : ''}</Text>
<StatusBar style="auto" />
  <Text>Insira os dados abaixo para calcular os Juros Compostos.</Text>
</View>
  ); }